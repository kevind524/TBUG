﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Dao_Kevin.Models;
using System.Data.SqlClient;

namespace Dao_Kevin.DAL
{
    public class DALProducts
    {
        private IConfiguration configuration;

        public DALProducts(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        internal string AddNewProduct(Product product)
        {
            //connect to db
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            //create query command
            string query = "INSERT INTO [dbo].[Products] " +
                "([Name],[Description],[Price],[InventoryAmount])" +
                "VALUES(@Name,@Description,@Price,@InventoryAmount);";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Name", product.Name);
            cmd.Parameters.AddWithValue("@Description", product.Description);
            cmd.Parameters.AddWithValue("@Price", product.Price);
            cmd.Parameters.AddWithValue("@InventoryAmount", product.Amount);

            // execute query
            cmd.ExecuteNonQuery();

            int PID;

            string queryPID = "SELECT [PID] FROM [dbo].[Products]" +
                " WHERE [Name] = @Name;";
            SqlCommand cmd2 = new SqlCommand(queryPID, conn);
            cmd2.Parameters.AddWithValue("@Name", product.Name);

            SqlDataReader reader = cmd2.ExecuteReader();
            reader.Read();
            PID = Convert.ToInt32(reader[0].ToString());
            reader.Close();

            //close connection
            conn.Close();

            return PID.ToString();
        }

        internal void UpdateInventory(string pID, int p)
        {
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = "UPDATE Products " +
                "SET InventoryAmount=InventoryAmount+@inventoryDelta" +
                "WHERE PID = @PID;";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@inventoryDelta", p);
            cmd.Parameters.AddWithValue("@PID", pID);

            cmd.ExecuteNonQuery();

            conn.Close();
        }

        internal LinkedList<Product> GetAllProducts()
        {
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = "SELECT Name,Description,PID,Price,InventoryAmount FROM Products;";
            SqlCommand cmd = new SqlCommand(query, conn);

            LinkedList<Product> allProds = new LinkedList<Product>();

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Product p = new Product();
                p.Name = reader["Name"].ToString();
                p.Description = reader["Description"].ToString();
                p.PID = reader["PID"].ToString();
                p.Price = Convert.ToDouble(reader["Price"]);
                p.Amount = Convert.ToInt32(reader["InventoryAmount"]);

                allProds.AddLast(p);
            }

            conn.Close();

            return allProds;
        }
    }
}
