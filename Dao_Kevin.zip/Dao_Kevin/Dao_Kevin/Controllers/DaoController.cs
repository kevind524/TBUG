﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Dao_Kevin.Models;
using Dao_Kevin.DAL;
using Microsoft.AspNetCore.Http;

namespace Dao_Kevin.Controllers
{
    public class DaoController : Controller
    {
        private readonly IConfiguration configuration;

        public DaoController(IConfiguration config)
        {
            this.configuration = config;
        }

        //return user to front page/Index webpage
        public IActionResult Index()
        {
            ViewBag.ShowLogInForm = true;
            return View();
        }

        //this entire method checks for user in database
        public IActionResult LogIn(LogInCredentials lic)
        {
            DALPerson dp = new DALPerson(configuration);

            PersonShort ps = dp.CheckLogInCredentials(lic);
            
            if (ps == null) //user is not in database   
            {
                ViewBag.ErrorMessage = "Username or Password is not valid";
                ViewBag.LogInMessage = "Login Failed";
                return View("Index");
            }
            else //user is in database
            {
                //this login session is now running in this username and password
                HttpContext.Session.SetString("uID", ps.PersonID); 
                HttpContext.Session.SetString("uFName", ps.FName); 
                ViewBag.UserFirstName = ps.FName;
            }

            //run 
            return View("Page2");
        }

        //Don't worry about this method for now
        //Go to EnterNewProduct view
        public IActionResult EnterNewProduct()
        {
            if (!this.IsUserLogedIn())
            {
                ViewBag.ShowLogInForm = true;
                ViewBag.LoginMessage = "User is not logged in ";
                return View("Index");
            }
            return View();
        }

        //Check if User is logged into database with each newly loaded webpage
        //Session check
        private bool IsUserLogedIn()
        {
            if (HttpContext.Session.GetString("uID") == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        //Don't worry about this method for now
        //Add produce to webpage
        public IActionResult AddProductToDB(Product product)
        {
            if (!this.IsUserLogedIn())
            {
                ViewBag.ShowLogInForm = true;
                ViewBag.LoginMessage = "User is not logged in ";
                return View("Index");
            }

            DALProducts dprod = new DALProducts(configuration);
            string PID = dprod.AddNewProduct(product);
            product.PID = PID;

            return View(product);
        }

        //Don't worry about this method for now
        //Show all products
        public IActionResult ShowProducts()
        {
            if (!this.IsUserLogedIn())
            {
                ViewBag.ShowLogInForm = true;
                ViewBag.LoginMessage = "User is not logged in ";
                return View("Index");
            }

            DALProducts dProds = new DALProducts(configuration);
            LinkedList<Product> allProducts = dProds.GetAllProducts();

            return View(allProducts);
        }
    }
}