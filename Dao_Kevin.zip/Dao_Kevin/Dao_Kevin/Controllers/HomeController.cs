﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Dao_Kevin.Models;
using Microsoft.Extensions.Configuration;
using Dao_Kevin.DAL;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Http;


namespace Dao_Kevin.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration configuration;

        public  HomeController(IConfiguration config)
        {
            this.configuration = config;
        }

        //open index webpage
        public IActionResult Index()
        {
            return View();
        }

        //open page2 webpage with user's session
        public IActionResult Page2(Person person)
        {
            DALPerson dp = new DALPerson(configuration);
            int uID = dp.addUser(person);

            person.UID = uID;

            HttpContext.Session.SetString("uID", uID.ToString());
            return View(person);
        }
        
        //open EditPerson webpage with user's session
        public IActionResult EditPerson()
        {
            int uID = Convert.ToInt32(HttpContext.Session.GetString("uID"));

            DALPerson dp = new DALPerson(configuration);
            Person person = dp.getPerson(uID); //call DALPerson.cs method to show information on EditPerson webpage

            return View(person);
        }

        //update information on user and return them to Page2
        public IActionResult UpdatePerson(Person person)
        {
            person.UID = Convert.ToInt32(HttpContext.Session.GetString("uID"));
            DALPerson dp = new DALPerson(configuration);
            dp.UpdateUser(person); //call DALPerson.cs method to update person in session

            return View("Page2", person);
        }

        //delete user information
        public IActionResult DeletePerson()
        {
            string uID = HttpContext.Session.GetString("uID");
            DALPerson dp = new DALPerson(configuration);

            Person person = dp.getPerson(Convert.ToInt32(uID));

            dp.DeletePerson(Convert.ToInt32(uID)); //call DALPerson.cs method to delete person in session

            return View(person);
        }
    }
}