﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dao_Kevin.Models
{
    public class Product
    {
        public String Name { get; set; }

        public String Description { get; set; }

        public double Price { get; set; }

        public int Amount { get; set; }

        public String PID { get; set; }
    }
}
