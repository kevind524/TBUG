﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dao_Kevin.Models
{
    public class Purchase
    {
        public Person Person { get; set; }
        public Product Product { get; set; }
    }
}
